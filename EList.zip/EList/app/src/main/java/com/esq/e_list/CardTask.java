package com.esq.e_list;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.Set;

public class CardTask extends AppCompatActivity {
    //Set bottomAppBar
    BottomAppBar bottomAppBar;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_card_item_task);
        //Set up bottom bar
        bottomAppBar = findViewById(R.id.bottom_app_bar);
        //Set bottom bar to Action bar as it is similar like toolbar
        setUpBottomAppBar();
        setUpFab();
        setUpRecyclerView();
    }

   //Set up bottom bar
    private void setUpBottomAppBar() {
        bottomAppBar = findViewById(R.id.bottom_app_bar);
        //Set bottom bar to Action bar as it is similar like toolbar
        setSupportActionBar(bottomAppBar);
        //Click event over Bottom bar navigation item
        bottomAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v , "Navigation icon is clicked", Snackbar.LENGTH_LONG)
                .setAction("UNDO", null)
                        .show();
            }
        });
    }

    //Set up fab
    private void setUpFab(){
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v , "Fab is clicked", Snackbar.LENGTH_LONG)
                        .setAction("UNDO", null)
                        .show();
            }
        });
    }

    //Inflate menu to bottom Bar: this adds the items to the action bar if present
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bottom_app_bar_menu , menu);
        //return super.onCreateOptionsMenu(menu);
        return true;
    }

    //handle click events of the menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.app_bar_settings:
                Toast.makeText(this, "onOptionsItemSelected: Settings icon Clicked", Toast.LENGTH_SHORT).show();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    //Set up recyclerView
    private void setUpRecyclerView() {
        recyclerView = (RecyclerView) findViewById(R.id.card_recycler_view);
        recyclerView.setHasFixedSize(true);
        int numberOfColumns = 2;
        recyclerView.setLayoutManager(new GridLayoutManager(this, numberOfColumns));
    }

}
